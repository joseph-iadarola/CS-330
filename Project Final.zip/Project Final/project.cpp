#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#include <GL/gl.h>
//#include <GL/glut.h>

#define _USE_MATH_DEFINES
#include <math.h>
# define M_PI  3.14159265358979323846  /* pi */

// image
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h> 

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <learnOpengl/camera.h>
#include <map>
#include <vector>
#include <iostream>


using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
const char* const WINDOW_TITLE = "Project"; // Macro for window title

// Variables for window width and height
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

// Stores the GL data relative to a given mesh
struct GLMesh
{
    //vertex array
    GLuint vao;
    //vertex buffer
    GLuint vbo;
    //vertex buffer
    GLuint vbos[2];
    //indices of the mesh
    GLuint nIndices;

    //indices to draw
    vector<float> verts;
    //translation properties of the shape
    vector<float> prop;
    vector<short> indices;

    //physical properties of the shape
    float height;
    float length;
    float radius;
    float number_of_sides;

    // each shape gets a matrix object
    glm::mat4 scale;
    glm::mat4 xrotation;
    glm::mat4 yrotation;
    glm::mat4 zrotation;
    glm::mat4 rotation;
    glm::mat4 translation;
    glm::mat4 model;
    glm::vec2 gUVScale;

    // texture information
    const char* texFilename;
    GLuint textureId;

    //texture wrapping mode: repeat texture
    GLint gTextWrapMode = GL_CLAMP_TO_BORDER;

};



struct Point {
    float x;
    float y;
    float z;

    bool operator <(const Point& right) const {
        if (x != right.x) return x < right.x;
        if (y != right.y) return y < right.y;
        return z < right.z;
    }
};

struct GLightMesh
{
    GLuint vao;         // Handle for the vertex array object
    GLuint vbo;         // Handle for the vertex buffer object
    GLuint nVertices;    // Number of indices of the mesh
};

//GLightMesh spotLightMesh;
GLightMesh keyLightMesh;
GLightMesh spotLightMesh;

vector<GLMesh> scene;

// Texture
GLuint gTextureId;
glm::vec2 gUVScale(5.0f, 5.0f);
GLint gTexWrapMode = GL_CLAMP_TO_BORDER;

// Main GLFW window
GLFWwindow* gWindow = nullptr;
// Shader program
GLuint gProgramId;
GLuint gLampProgramId;
bool perspective = false;

// camera
Camera gCamera(glm::vec3(3.0f, 1.0f, 10.0f));
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;


//// Light color, position and scale
glm::vec3 gSpotLightColor(1.0f, 1.0f, 0.40f); //yellow
glm::vec3 gSpotLightPosition(3.5f, 2.0f, -1.5f);
glm::vec3 gSpotLightScale(0.1f);

// Light color, position and scale
glm::vec3 gKeyLightColor(1.0f, 1.0f, 0.0f);
glm::vec3 gKeyLightPosition(2.5f, 5.0f, 1.5f);
glm::vec3 gKeyLightScale(0.5f);

// Lamp animation
bool gIsLampOrbiting = true;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char*[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh &mesh);
void UDestroyMesh(GLMesh &mesh);
void URender(vector<GLMesh> scene);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId);
// texture create
bool UCreateTexture(const char* filename, GLuint& textureId);
void UCreateLightMesh(GLightMesh& lightMesh);
void UDestroyShaderProgram(GLuint programId);
void UDestroyTexture(GLuint textureId);
void CreateScene(vector<GLMesh>& scene);
void UBuildCylinder(GLMesh& mesh);
void UBuildTorus(GLMesh& mesh);
void VertsInsert(GLMesh& mesh, Point point, float texX, float texY);
void UBuildHalfSphere(GLMesh& mesh);
void UBuildSphere(GLMesh& mesh);
void UBuildCone(GLMesh& mesh);
void UBuildPrism(GLMesh& mesh);
void UBuildCircle(GLMesh& mesh);
void UBuildPlane(GLMesh& mesh);



/* Vertex Shader Source Code*/
const GLchar * vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
        vertexTextureCoordinate = textureCoordinate;
    }
);


/* Fragment Shader Source Code*/
const GLchar * fragmentShaderSource = GLSL(440,
    //out vec4 fragmentColor;
    //in vec3 shapeColor;
    //in vec2 vertexTextureCoordinate; // for texture coordinates, not color
    //uniform sampler2D uTexture;
    //uniform vec2 uvScale;
    //void main(){
    //    fragmentColor = texture(uTexture, vertexTextureCoordinate) * vec4(shapeColor, 1.0);
    //}
    in vec3 vertexNormal; // For incoming normals
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec2 vertexTextureCoordinate;
    out vec4 fragmentColor; // For outgoing cube color to the GPU
    // Uniform / Global variables for object color, light color, light position, and camera/view position
    uniform vec3 objectColor;
    uniform vec3 lightColor;
    uniform vec3 keyLightColor;
    uniform vec3 lightPos;
    uniform vec3 keyLightPos;
    uniform vec3 viewPosition;
    uniform sampler2D uTexture; // Useful when working with multiple textures
    uniform vec2 uvScale;
    void main()
    {
        /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/
        //Calculate Ambient lighting*/
        float ambientStrength = 1.0f; // Set ambient or global lighting strength
        float keyStrength = 0.10f;
        vec3 ambient = ambientStrength * lightColor; // Generate ambient light color
        vec3 key = keyStrength * keyLightColor;
        //Calculate Diffuse lighting*/
        vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
        vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        vec3 keyLightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
        float keyImpact = max(dot(norm, keyLightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
        vec3 diffuse = impact * lightColor; // Generate diffuse light color
        vec3 keyDiffuse = keyImpact * keyLightColor;
        //Calculate Specular lighting*/
        float specularIntensity = 0.8f; // Set specular light strength
        float highlightSize = 16.0f; // Set specular highlight size
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
        vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
        //Calculate specular component
        float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        vec3 specular = specularIntensity * specularComponent * lightColor;
        // Texture holds the color to be used for all three components
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
        // Calculate phong result
        vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
        fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
    }
);

// Light Shader Source Code
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);

// Light Fragment Shader Source Code
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing light color to the GPU

    void main()
    {
        fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
    }
);

void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;


    CreateScene(scene);
    

    for (auto& m : scene)
    {
        if (!UCreateTexture(m.texFilename, m.textureId))
        {
            cout << "Failed to load texture " << m.texFilename << endl;
            cin.get();
            return EXIT_FAILURE;

        }
        if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId)) {
            cout << "Failed to load texture " << endl;
            cin.get();
            return EXIT_FAILURE;
        }
    }

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Create Light Object
    UCreateLightMesh(spotLightMesh);
    UCreateLightMesh(keyLightMesh);


    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    //rendering loop
    //keep checking if window has closed
    while (!glfwWindowShouldClose(gWindow))
    {
        //bg color of window
       // glClearColor(1.0f, 0.5f, 0.0f, 1.0f);


        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        //process user input
        UProcessInput(gWindow);

        //render frame
        URender(scene);

        glfwPollEvents();
    }

    //clean up
    for (auto& m : scene)
    {
        UDestroyMesh(m);
    }

    scene.clear();

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader programs
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);

    //exit with success!
    exit(EXIT_SUCCESS);
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    //draw line
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    //fill shape
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    // Modify light position
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS)
        gSpotLightPosition.x -= 0.05f;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS)
        gSpotLightPosition.x += 0.05f;
    if (glfwGetKey(window, GLFW_KEY_I) == GLFW_PRESS)
        gSpotLightPosition.z -= 0.05f;
    if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS)
        gSpotLightPosition.z += 0.05f;
    if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS)
        gSpotLightPosition.y -= 0.05f;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        gSpotLightPosition.y += 0.05f;



    // Turn off key light [ ]
    if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
    {
        gKeyLightColor.r = 0.0f;
        gKeyLightColor.g = 0.0f;
        gKeyLightColor.b = 0.0f;

    }

    // Turn off key light [ ]
    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
    {
        gKeyLightColor.r = 1.0f;
        gKeyLightColor.g = 0.0f;
        gKeyLightColor.b = 1.0f;

    }

    // Toggle perspective versus ortho view
    // V / B
    if (glfwGetKey(window, GLFW_KEY_V) == GLFW_PRESS)
        perspective = false;
    if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS)
        perspective = true;

    // Pause and resume lamp orbiting
    static bool isLKeyDown = false;
    if (glfwGetKey(window, GLFW_KEY_LEFT_ALT) == GLFW_PRESS && !gIsLampOrbiting)
        gIsLampOrbiting = true;
    else if (glfwGetKey(window, GLFW_KEY_RIGHT_ALT) == GLFW_PRESS && gIsLampOrbiting)
        gIsLampOrbiting = false;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
    cout << gCamera.MovementSpeed << endl;
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender(vector<GLMesh> scene)
{
    // Borrowed from the Tutorial; animates the Spot Light to circle around the scene
    constexpr float angularVelocity = glm::radians(45.0f);
    if (gIsLampOrbiting)
    {
        glm::vec4 newPosition = glm::rotate(angularVelocity * gDeltaTime, glm::vec3(0.0f, 0.0f, 1.0f)) * glm::vec4(gSpotLightPosition, 1.0f);
        gSpotLightPosition.x = newPosition.x;
        gSpotLightPosition.y = newPosition.y;
        gSpotLightPosition.z = newPosition.z;
    }
    
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    
    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    // Transforms the camera: move the camera back (z axis)
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a orthographic projection
    glm::mat4 projection;
    if (!perspective) {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);

   

    // loop to draw each shape individually
    for (auto i = 0; i < scene.size(); ++i)
    {
        auto mesh = scene[i];

        // activate vbo's within mesh's vao
        glBindVertexArray(mesh.vao);

        // Set the shader to be used
        glUseProgram(gProgramId);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(gProgramId, "model");
        GLint viewLoc = glGetUniformLocation(gProgramId, "view");
        GLint projLoc = glGetUniformLocation(gProgramId, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(mesh.model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        //NEW STUFF
         // Reference matrix uniforms from the shape shader program for the shape color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");

        // Spotlight
        GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
        GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");

        // Key light
        GLint keyLightColorLoc = glGetUniformLocation(gProgramId, "keyLightColor");
        GLint keyLightPositionLoc = glGetUniformLocation(gProgramId, "keyLightPos");

        // Camera view
        GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

        // Pass color, light, and camera data to the shape shader 
        glUniform3f(objectColorLoc, mesh.prop[0], mesh.prop[1], mesh.prop[2]);

        // Spot Light
        glUniform3f(lightColorLoc, gSpotLightColor.r, gSpotLightColor.g, gSpotLightColor.b);
        glUniform3f(lightPositionLoc, gSpotLightPosition.x, gSpotLightPosition.y, gSpotLightPosition.z);

        // Key Light
        glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
        glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);


        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        //END NEW STUFF


        GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(mesh.gUVScale));
        
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mesh.textureId);

        // Draws the triangles
        //glDrawArrays(GL_TRIANGLES, 0, mesh.nIndices);
        glDrawElements(GL_TRIANGLES, mesh.nIndices, GL_UNSIGNED_SHORT, nullptr);
    }


    //NEW STUFF
    // Draw the Spot Light
    glUseProgram(gLampProgramId);
    glBindVertexArray(spotLightMesh.vao);

    // Light location and Scale
    glm::mat4 model = glm::translate(gSpotLightPosition) * glm::scale(gSpotLightScale);

    // Matrix uniforms from the Light Shader program
    GLint modelLoc = glGetUniformLocation(gLampProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gLampProgramId, "view");
    GLint projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Matrix data
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draw the light
    glDrawArrays(GL_TRIANGLES, 0, spotLightMesh.nVertices);



    // Draw the Key Light
    glUseProgram(gLampProgramId);
    glBindVertexArray(keyLightMesh.vao);

    // Light location and Scale
    model = glm::translate(gKeyLightPosition) * glm::scale(gKeyLightScale);

    // Matrix uniforms from the Light Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Matrix data
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draw the light
    glDrawArrays(GL_TRIANGLES, 0, keyLightMesh.nVertices);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glUseProgram(0);
    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{

    //cout << mesh.verts.size() << endl;
    cout << mesh.indices.size() << endl;

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = mesh.indices.size();
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, mesh.verts.size() * sizeof(float), mesh.verts.data(), GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh.indices.size() * sizeof(short), mesh.indices.data(), GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    // scale the object
    mesh.scale = glm::scale(glm::vec3(mesh.prop[4], mesh.prop[5], mesh.prop[6]));


    // rotate the object (x, y, z) (0 - 6.4, to the right)

    mesh.xrotation = glm::rotate(mesh.prop[7], glm::vec3(mesh.prop[8], mesh.prop[9], mesh.prop[10]));
    mesh.yrotation = glm::rotate(mesh.prop[11], glm::vec3(mesh.prop[12], mesh.prop[13], mesh.prop[14]));
    mesh.zrotation = glm::rotate(mesh.prop[15], glm::vec3(mesh.prop[16], mesh.prop[17], mesh.prop[18]));

    // move the object (x, y, z)
    mesh.translation = glm::translate(glm::vec3(mesh.prop[19], mesh.prop[20], mesh.prop[21]));

    mesh.model = mesh.translation * mesh.xrotation * mesh.zrotation * mesh.yrotation * mesh.scale;

    mesh.gUVScale = glm::vec2(mesh.prop[22], mesh.prop[23]);		// scales the texture
    //mesh.gUVScale = glm::vec2(2.0f, 2.0f);		// scales the texture
}

/// <summary>
/// Main function to build 3D scene. 
/// Create mesh objects and load in properties before calling coorect UBuild function and adding mesh to scene vector 
/// </summary>
/// <param name="scene">Vector to store GLMesh objects</param>
void CreateScene(vector<GLMesh>& scene) {
    //Soda can
    GLMesh can;
    can.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        0.0f,	0.0f,	2.5f,           //translate
        1.0f,	1.0f
    };
    can.height = 0.85f;
    can.radius = 0.25f;
    can.number_of_sides = 20.0f;
    can.texFilename = "cokecan2.jpg";
    can.gTextWrapMode = GL_CLAMP_TO_EDGE;
    UBuildCylinder(can);
    scene.push_back(can);

    //Soda Can Rim
    GLMesh rim;
    rim.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        1.0f,	0.7f,	1.5f,           //translate x, y, z
        1.0f,	1.0f
    };
    rim.height = 0.01f;
    rim.radius = 0.24f;
    rim.texFilename = "brushedsteel.jpg";
    UBuildTorus(rim);
    scene.push_back(rim);

    //Soda Can Top
    GLMesh top;
    top.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        0.0f,	1.71f,	2.5f,           //translate x, y, z
        1.0f,	1.0f
    };
    top.height = 0.01f;
    top.radius = 0.24f;
    top.number_of_sides = 10.0f;
    top.texFilename = "can-soda-top.jpg";
    UBuildCircle(top);
    scene.push_back(top);

    //Flatbrim Hat
    GLMesh hat;
    hat.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        0.0f,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        5.0f,	0.0f,	2.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    hat.radius = 1.0f;
    hat.height = 12.0f;
    hat.number_of_sides = 12.0f;
    hat.texFilename = "grey_fabric.jpg";
    UBuildHalfSphere(hat);
    scene.push_back(hat);

    //Hat Brim
    GLMesh end_brim;
    end_brim.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI/2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        4.0f,	0.0f,	4.8f,           //translate x, y, z
        1.0f,	1.0f
    };
    end_brim.height = 0.03f;
    end_brim.radius = 0.7f;
    end_brim.number_of_sides = 16.0f;
    end_brim.texFilename = "black-fabric.jpg";
    UBuildCylinder(end_brim);
    scene.push_back(end_brim);

    //Hat Tip
    GLMesh hat_tip;
    hat_tip.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        0.0f,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        5.0f,	1.95f,	2.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    hat_tip.radius = 0.0625f;
    hat_tip.height = 6.0f;
    hat_tip.number_of_sides = 6.0f;
    hat_tip.texFilename = "black-fabric.jpg";
    UBuildSphere(hat_tip);
    scene.push_back(hat_tip);

    //Card Box
    GLMesh box;
    box.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        0.0f,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        1.5f,	0.0f,	2.1f,           //translate x, y, z
        1.0f,	1.0f
    };
    box.height = 0.125f;
    box.length = 0.50f;
    box.radius = 0.75f;
    box.texFilename = "Red-Box2.png";
    UBuildPrism(box);
    scene.push_back(box);

    //Grinder
    GLMesh grind_top;
    grind_top.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        1.0f,	0.7f,	4.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    grind_top.radius = 0.25f;
    grind_top.height = 0.0833f;
    grind_top.number_of_sides = 10.0f;
    grind_top.texFilename = "brushedsteel.jpg";
    UBuildCylinder(grind_top);
    scene.push_back(grind_top);

    //Grinder Middle
    GLMesh grind_mid;
    grind_mid.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        1.0f,	0.29f,	4.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    grind_mid.radius = 0.25f;
    grind_mid.height = 0.2083f;
    grind_mid.number_of_sides = 18.0f;
    grind_mid.texFilename = "brushedsteel.jpg";
    UBuildCylinder(grind_mid);
    scene.push_back(grind_mid);


    //Grinder Bottom
    GLMesh grind_bot;
    grind_bot.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        -M_PI_2,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        1.0f,	0.255f,	4.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    grind_bot.radius = 0.25f;
    grind_bot.height = 0.04166f;
    grind_bot.number_of_sides = 10.0f;
    grind_bot.texFilename = "brushedsteel.jpg";
    UBuildCylinder(grind_bot);
    scene.push_back(grind_bot);

    //Desk plane
    GLMesh desk;
    desk.prop = {
        1.0f,	1.0f,	1.0f,	1.0f,   //color r, g, b, a
        2.0f,	2.0f,	2.0f,           //scale x, y, z
        0.0f,	1.0f,	0.0f,	0.0f,   //x rotation
        0.0f,	0.0f,	1.0f,	0.0f,   //y rotation
        0.0f,	0.0f,	0.0f,	1.0f,   //z rotation
        0.0f,	0.0f,	0.0f,           //translate x, y, z
        1.0f,	1.0f
    };
    desk.texFilename = "beechwood_natural.png";
    UBuildPlane(desk);
    scene.push_back(desk);

}

/// <summary>
/// Builds 3D cylinder with one layer of triangles circling sides
/// </summary>
/// <param name="mesh"> Cylinder mesh</param>
void UBuildCylinder(GLMesh& mesh) {

    float r = mesh.radius;
    float l = mesh.height;
    float s = mesh.number_of_sides;
    float h = mesh.height;
    short index = 0;
    map<Point, short> checkedMap;
    Point holdPoint;

    const float radialStep = 2.0f * M_PI / s;
    const float textStep = 1.0f / s;


    for (auto i = 1; i < s + 1; i++)
    {
        float angle0Sin = sin(i * radialStep);
        float angle0Cos = cos(i * radialStep);
        float angle1Sin = sin((i + 1) * radialStep);
        float angle1Cos = cos((i + 1) * radialStep);
        // triangle fan, bottom
        holdPoint.x = 0.5f;
        holdPoint.y = 0.5f;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f, 0.125f); // origin (0.5, 0.5) works best for textures
            //VertsInsert(mesh, holdPoint, 0.5f, 0.5f); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        
        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f+(r * angle0Cos), (0.125f + (0.125f * angle0Sin))); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));


        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (r * angle1Cos), (0.125f + (0.125f * angle1Sin))); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
    }

    for (auto i = 1; i < s + 1; i++)
    {
        float angle0Sin = sin(i * radialStep);
        float angle0Cos = cos(i * radialStep);
        float angle1Sin = sin((i + 1) * radialStep);
        float angle1Cos = cos((i + 1) * radialStep);
        // triangle fan, top
        holdPoint.x = 0.5f;
        holdPoint.y = 0.5f;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f, 0.875f); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        
        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (r * angle0Cos), (0.875f + (0.125f * angle0Sin))); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        
        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (r * angle1Cos), (0.875f + (0.125f * angle1Sin))); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
    }

    
    float j = 1.0f / (s);	// for calculating texture location

    // sides
    for (auto i = 1; i <= s; i++)
    {
        float angle0Sin = sin(i * radialStep);
        float angle0Cos = cos(i * radialStep);
        float angle1Sin = sin((i + 1) * radialStep);
        float angle1Cos = cos((i + 1) * radialStep);
        
            //am
        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.0f, i / s); //0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

            
        //bn
        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 1.0f, i / s); // 0.75f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        

        //cp
        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 1.0f, (i + j) / s); //0.75f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        //am,bn,cw
        //cg,b'g,am


        //am
        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.0f, i / s); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        //bw
        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.0f, (j + i) / s); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));

        //cp
        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = l;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 1.0f, (j + i) / s); // 0.75f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));


        
        //k += j;
    }


   

    UCreateMesh(mesh);
}

/// <summary>
/// Helper function for quick adding vertices 
/// </summary>
/// <param name="mesh">GLmesh to have verts added to</param>
/// <param name="point">x, y, z values to make vert point</param>
/// <param name="texX"> x value texture coordinate</param>
/// <param name="texY"> y value texture coordinate</param>
void VertsInsert(GLMesh& mesh,Point point, float texX, float texY) {
    mesh.verts.push_back(point.x);
    mesh.verts.push_back(point.y);
    mesh.verts.push_back(point.z);
    mesh.verts.push_back(mesh.prop[0]);
    mesh.verts.push_back(mesh.prop[1]);
    mesh.verts.push_back(mesh.prop[2]);
    mesh.verts.push_back(mesh.prop[3]);
    mesh.verts.push_back(texX);
    mesh.verts.push_back(texY);
}

/// <summary>
/// Build torus by adding vertices and indicies to mesh
/// </summary>
/// <param name="mesh"> GLMesh to store verts and indices</param>
void UBuildTorus(GLMesh& mesh) {
    int _nR = 16; //number of sections
    int _nr = 16; //number of sections
    float _r = mesh.height; //radius of tiny circles (height/2)
    float _R = mesh.radius; //radius of torus
    float du = 2 * M_PI / _nR;
    float dv = 2 * M_PI / _nr;
    map<Point, short> checkedMap;
    short indexCount = 0;
    Point holdPoint;


    for (int i = 0; i < _nR; i++) {

        float u = i * du;

        for (int j = 0; j <= _nr; j++) {

            float v = j * dv;

            for (int k = 0; k < 2; k++){
                float uu = u + k * du;
                // compute vertex
                holdPoint.x = (_R + _r * cos(v)) * cos(uu);
                holdPoint.y = (_R + _r * cos(v)) * sin(uu);
                holdPoint.z = _r * sin(v) + .51;
                

                // compute texture coords
                float tx = uu / (2 * M_PI);
                float ty = v / (2 * M_PI);

                if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
                    checkedMap.insert({ holdPoint, indexCount });
                    mesh.indices.push_back(indexCount);
                    //increase for next point-key
                    indexCount++;
                    // add vertex 
                    mesh.verts.push_back(holdPoint.x);
                    mesh.verts.push_back(holdPoint.y);
                    mesh.verts.push_back(holdPoint.z);
                    mesh.verts.push_back(mesh.prop[0]);
                    mesh.verts.push_back(mesh.prop[1]);
                    mesh.verts.push_back(mesh.prop[2]);
                    mesh.verts.push_back(mesh.prop[3]);
                    mesh.verts.push_back(tx);
                    mesh.verts.push_back(ty);
                }
                else
                    mesh.indices.push_back(checkedMap.at(holdPoint));

            }
            // incr angle
            //v += dv;
        }
    }
    UCreateMesh(mesh);
}

/// <summary>
/// Build half sphere by adding vertices and indicies to mesh
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildHalfSphere(GLMesh& mesh) {
    float radius = mesh.radius;
    float rings = mesh.height;
    float sectors = mesh.number_of_sides;
    float const R = 1. / (float)(rings - 1);
    float const S = 1. / (float)(sectors - 1);
    float x, y, z, xy;                              // vertex position
    float s, t;                                     // vertex texCoord
    float sectorCount = mesh.number_of_sides;
    float stackCount = mesh.height;
    float sectorStep = 2 * M_PI / sectorCount;
    float stackStep = M_PI / stackCount;
    float sectorAngle, stackAngle;
    int k1, k2;
    for (int i = 0; i <= stackCount; ++i)
    {
        stackAngle = M_PI / 2 - i * stackStep;        // starting from pi/2 to -pi/2
        xy = radius * cosf(stackAngle);             // r * cos(u)
        z = radius * sinf(stackAngle);              // r * sin(u)
        k1 = i * (sectorCount + 1);     // beginning of current stack
        k2 = k1 + sectorCount + 1;      // beginning of next stack

        // add (sectorCount+1) vertices per stack
        // the first and last vertices have same position and normal, but different tex coords
        for (int j = 0; j <= sectorCount; ++j, ++k1, ++k2)
        {
            sectorAngle = j * sectorStep;           // starting from 0 to 2pi

            // vertex position (x, y, z)
            x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
            y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
            mesh.verts.push_back(x);
            mesh.verts.push_back(abs(y));   //This creates hemisphere
            mesh.verts.push_back(z);

            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            // vertex tex coord (s, t) range between [0, 1]
            s = (float)j / sectorCount;
            t = (float)i / stackCount;
            mesh.verts.push_back(s);
            mesh.verts.push_back(t);

            // 2 triangles per sector excluding first and last stacks
            // k1 => k2 => k1+1
            if (i != 0)
            {
                mesh.indices.push_back(k1);
                mesh.indices.push_back(k2);
                mesh.indices.push_back(k1 + 1);
            }

            // k1+1 => k2 => k2+1
            if (i != (stackCount - 1))
            {
                mesh.indices.push_back(k1 + 1);
                mesh.indices.push_back(k2);
                mesh.indices.push_back(k2 + 1);
            }

        }
    }
    UCreateMesh(mesh);
}

/// <summary>
/// Build full shpere by storing vertices and indices in mesh
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildSphere(GLMesh& mesh) {
    float radius = mesh.radius;
    float rings = mesh.height;
    float sectors = mesh.number_of_sides;
    float const R = 1. / (float)(rings - 1);
    float const S = 1. / (float)(sectors - 1);
    float x, y, z, xy;                              // vertex position
    float s, t;                                     // vertex texCoord
    float sectorCount = mesh.number_of_sides;
    float stackCount = mesh.height;
    float sectorStep = 2 * M_PI / sectorCount;
    float stackStep = M_PI / stackCount;
    float sectorAngle, stackAngle;
    int k1, k2;
    for (int i = 0; i <= stackCount; ++i)
    {
        stackAngle = M_PI / 2 - i * stackStep;        // starting from pi/2 to -pi/2
        xy = radius * cosf(stackAngle);             // r * cos(u)
        z = radius * sinf(stackAngle);              // r * sin(u)
        k1 = i * (sectorCount + 1);     // beginning of current stack
        k2 = k1 + sectorCount + 1;      // beginning of next stack

        // add (sectorCount+1) vertices per stack
        // the first and last vertices have same position and normal, but different tex coords
        for (int j = 0; j <= sectorCount; ++j, ++k1, ++k2)
        {
            sectorAngle = j * sectorStep;           // starting from 0 to 2pi

            // vertex position (x, y, z)
            x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
            y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
            mesh.verts.push_back(x);
            mesh.verts.push_back(y);
            mesh.verts.push_back(z);

            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            mesh.verts.push_back(1.0f);
            // vertex tex coord (s, t) range between [0, 1]
            s = (float)j / sectorCount;
            t = (float)i / stackCount;
            mesh.verts.push_back(s);
            mesh.verts.push_back(t);

            // 2 triangles per sector excluding first and last stacks
            // k1 => k2 => k1+1
            if (i != 0)
            {
                mesh.indices.push_back(k1);
                mesh.indices.push_back(k2);
                mesh.indices.push_back(k1 + 1);
            }

            // k1+1 => k2 => k2+1
            if (i != (stackCount - 1))
            {
                mesh.indices.push_back(k1 + 1);
                mesh.indices.push_back(k2);
                mesh.indices.push_back(k2 + 1);
            }

        }
    }
    UCreateMesh(mesh);
}

/// <summary>
/// Build cone by storing vertices and indices in mesh
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildCone(GLMesh& mesh) {
    vector<float> c = { mesh.prop[0], mesh.prop[1], mesh.prop[2], mesh.prop[3] };

    float r = mesh.radius;
    float h = mesh.height;
    float s = mesh.number_of_sides;

    const float sectorStep = 2.0f * M_PI / s;
    const float textStep = 1.0f / s;
    float textureXLoc = 0.0f;

    vector<float> v;
    Point holdPoint;
    short index = 0;
    map<Point, short> checkedMap;

    for (auto i = 1; i < s + 1; i++) {

        float one = 0.5f + r * cos(i * sectorStep);
        float two = 0.5f + r * sin(i * sectorStep);

        one -= 0.5f;
        one *= 2.0f;

        two -= 0.5f;
        two *= 2.0f;

        c[0] = one;
        c[2] = two;


        // triangle fan, bottom
        holdPoint.x = 0.5f;
        holdPoint.y = 0.0f;
        holdPoint.z = 0.5f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f, 0.25f); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        holdPoint.x = 0.5f + r * cos(i * sectorStep);
        holdPoint.y = 0.0f;
        holdPoint.z = 0.5f + r * sin(i * sectorStep);
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (r * cos((i)*sectorStep)), 0.25f + (0.25f * sin((i)*sectorStep))); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        holdPoint.x = 0.5f + r * cos((i+1) * sectorStep);
        holdPoint.y = 0.0f;
        holdPoint.z = 0.5f + r * sin((i+1) * sectorStep);
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (r * cos((i + 1) * sectorStep)), 0.25f + (0.25f * sin((i + 1) * sectorStep))); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        // side triangle + point
        holdPoint.x = 0.5f + r * cos(i * sectorStep);
        holdPoint.y = 0.0f;
        holdPoint.z = 0.5f + r * sin(i * sectorStep);
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, textureXLoc, 0.5f); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        holdPoint.x = 0.5f + r * cos((i+1) * sectorStep);
        holdPoint.y = 0.0f;
        holdPoint.z = 0.5f + r * sin((i+1) * sectorStep);
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, textureXLoc+textStep, 0.5f); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        holdPoint.x = 0.5f;
        holdPoint.y = h;
        holdPoint.z = 0.5f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, textureXLoc+(textStep/2), 1.0f); // 0.25f
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
        textureXLoc += textStep;

    }

    UCreateMesh(mesh);
}

/// <summary>
/// Build rectangular prism 
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildPrism(GLMesh& mesh) {
    Point holdPoint;
    float l = mesh.length;
    float h = mesh.height;
    float w = mesh.radius;
    GLfloat v[] = {
        0.0f, 0.0f, 0.0f, 0.586f, 0.137f,  //A 0
        l, 0.0f, 0.0f, 0.0f, 0.137f,     //B 1    
        0.0f, h, 0.0f, 0.50f, 0.137f,     //C 2
        l, h, 0.0f, .10f, 0.137f,        //D 3
        0.0f, 0.0f, w, 0.50f, 1.0f,     //a 4
        l, 0.0f, w, 0.10f, 1.0f,        //b 5 
        0.0f, h, w, 0.50f, 0.863f,        //c 6
        l, h, w, 0.10f, 0.863f,           //d 7
        l, 0.0f, w, 0.0f, 0.863f,        //b' 8
        l, 0.0f, w, 1.0f, 0.863f,        //b'' 9
        0.0f, 0.0f, w, 0.586f, 0.863f,     //a' 10
        l, 0.0f, 0.0f, 1.0f, 0.137f,     //B' 11
        0.0f, h, 0.0f, 0.586f, 0.0f,     //C' 12
        l, h, 0.0f, 1.0f, 0.0f        //D' 13
    };
    for (int i = 0; i < 70; i += 5) {
        holdPoint.x = v[i];
        holdPoint.y = v[i + 1];
        holdPoint.z = v[i + 2];
        VertsInsert(mesh, holdPoint, v[i + 3], v[i + 4]);
    }


    GLushort in[] = {
        1,8,7,
        1,3,7,
        3,2,6,
        3,7,6,
        4,5,7,
        4,6,7,
        0,10,6,
        0,2,6,
        11,0,10,
        11,9,10,
        0,11,13,
        0,12,13
    };
    for (int i = 0; i < 36;i++) {
        mesh.indices.push_back(in[i]);
    }

    UCreateMesh(mesh);
}

/// <summary>
/// Build base plane for desk
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildPlane(GLMesh& mesh) {
    mesh.verts = {
        -5.0f,	0.0f,	-5.0f, 	    0.0f,	1.0f,	0.0f,	1.0f,	0.0f,	1.0f,	// 0
        0.0f,	0.0f,	 5.0f,	    0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	0.0f,	// 1
        -5.0f,	0.0f,	 5.0f,	    0.0f,	1.0f,	0.0f,	1.0f,	0.0f,	0.0f,	// 2
        0.0f,	0.0f,	-5.0f, 	    0.0f,	1.0f,	0.0f,	1.0f,	0.5f,	1.0f,	// 3
        5.0f,	0.0f,	-5.0f, 	    0.0f,	1.0f,	0.0f,	1.0f,	1.0f,	1.0f,	// 4
        5.0f,	0.0f,	 5.0f, 	    0.0f,	1.0f,	0.0f,	1.0f,	1.0f,	0.0f,	// 5
    };

    mesh.indices = {
        0,1,2,
        0,2,3,
        3,2,5,
        3,5,4
    };

    UCreateMesh(mesh);
}

/// <summary>
/// Build 2D circle 
/// </summary>
/// <param name="mesh">GLMesh to store verts and indices</param>
void UBuildCircle(GLMesh& mesh) {
    vector<float> c = { mesh.prop[0], mesh.prop[1], mesh.prop[2], mesh.prop[3] };

    float r = mesh.radius;
    float l = mesh.height;
    float s = mesh.number_of_sides;
    //float h = mesh.height;
    short index = 0;
    map<Point, short> checkedMap;
    Point holdPoint;

    const float radialStep = 2.0f * M_PI / s;
    const float textStep = 1.0f / s;



    for (auto i = 1; i < s + 1; i++)
    {
        float angle0Sin = sin(i * radialStep);
        float angle0Cos = cos(i * radialStep);
        float angle1Sin = sin((i + 1) * radialStep);
        float angle1Cos = cos((i + 1) * radialStep);
        // triangle fan, top
        holdPoint.x = 0.5f;
        holdPoint.y = 0.5f;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f, 0.5f); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));


        holdPoint.x = 0.5f + r * angle0Cos;
        holdPoint.y = 0.5f + r * angle0Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (0.5f * angle0Cos), 0.5f + (0.5f * angle0Sin)); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));


        holdPoint.x = 0.5f + r * angle1Cos;
        holdPoint.y = 0.5f + r * angle1Sin;
        holdPoint.z = 0.0f;
        if (!(checkedMap.count(holdPoint)) || checkedMap.empty()) {
            checkedMap.insert({ holdPoint, index });
            mesh.indices.push_back(index);
            index++;
            VertsInsert(mesh, holdPoint, 0.5f + (0.5f * angle1Cos), 0.5f + (0.5f * angle1Sin)); // origin (0.5, 0.5) works best for textures
        }
        else
            mesh.indices.push_back(checkedMap.at(holdPoint));
    }
    UCreateMesh(mesh);
}


void UDestroyMesh(GLMesh &mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}

bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);



        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Template for creating a cube light
void UCreateLightMesh(GLightMesh& lightMesh)
{
    // Position and Color data
    GLfloat verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f, //0
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f, //0

       //Front Face         //Positive Z Normal
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
       0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
      -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
      -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

      //Left Face          //Negative X Normal
     -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //0
     -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //0
     -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Right Face         //Positive X Normal
     0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
     0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
     0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

     //Bottom Face        //Negative Y Normal
    -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f, //0
     0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
     0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
     0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f, //0

    //Top Face           //Positive Y Normal
   -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
    0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
    0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
    0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
   -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
   -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };

    //NEW INDICES STUFF
    

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    lightMesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &lightMesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(lightMesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &lightMesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, lightMesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}
